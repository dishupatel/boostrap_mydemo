
$(document).ready(function(){

/*add unique id*/
$("ul.sub-menu li").each(function(n) {
     $(this).attr("id", "img_" + n);
});

/*menu hover display images js*/
  $('ul.sub-menu li').click(function(){
     var Li_Id = $(this).id;     
     $('#display_img').attr('src','img/'+this.id+'.jpg');
   });      

});